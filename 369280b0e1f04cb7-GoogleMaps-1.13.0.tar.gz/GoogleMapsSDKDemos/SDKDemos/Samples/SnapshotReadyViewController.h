#import <UIKit/UIKit.h>

@interface SnapshotReadyViewController : UIViewController

@end
