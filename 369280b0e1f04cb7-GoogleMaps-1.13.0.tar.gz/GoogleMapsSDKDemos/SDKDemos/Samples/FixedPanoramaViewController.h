#import <UIKit/UIKit.h>

@interface FixedPanoramaViewController : UIViewController

@end
